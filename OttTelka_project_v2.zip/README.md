OttTelka - minimal Android player project (ExoPlayer)
-----------------------------------------------------

This project plays a DASH .mpd URL using ExoPlayer.
Dark theme with controller visible and autoplay enabled.

How to build locally:
1. Open Android Studio.
2. File -> Open -> select this folder.
3. Let Gradle sync and build.
4. Build -> Build APK(s)

Stream URL is set in MainActivity.kt (variable streamUrl).
